

<div class="center">
    <h1>Login</h1>
</div>
<div class="center">
    <form action="router.php?c=login&a=login" method="post">
        Username <input type="text" name="username"><br><br>
        Password <input type="password" name="password"><br><br>
        <input type="submit" value="login">
    </form>
</div>
